from selenium import webdriver
from webdriver_manager.opera import OperaDriverManager
import time

class Chrome_WDM_Config():

    def chrome_wdm_test(self):
        driver = webdriver.Opera(executable_path=OperaDriverManager().install())

        driver.get('https://cht.konnect.csttestserver.com/')
        time.sleep(3)
        driver.close()
        print('CHT opened and closed successfully')

test_obj = Chrome_WDM_Config()
test_obj.chrome_wdm_test()