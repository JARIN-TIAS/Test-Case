from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.firefox import GeckoDriverManager
import time

class Firefox_WDM_Config():

    def firefox_wdm_test(self):
        driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()))

        driver.get('https://cht.konnect.csttestserver.com/')
        time.sleep(3)
        driver.close()
        print('CHT opened and closed successfully')


test_obj= Firefox_WDM_Config()
test_obj.firefox_wdm_test()