from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import time

class Chrome_WDM_Config():

    def chrome_wdm_test(self):
        driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))

        driver.get('https://cht.konnect.csttestserver.com/')
        time.sleep(3)
        driver.close()
        print('CHT opened and closed successfully')

test_obj = Chrome_WDM_Config()
test_obj.chrome_wdm_test()