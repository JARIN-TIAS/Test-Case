from selenium import webdriver
from selenium.webdriver.edge.service import Service as EdgeService
from webdriver_manager.microsoft import EdgeChromiumDriverManager
import time

class Chrome_WDM_Config():

    def chrome_wdm_test(self):
        driver = webdriver.Edge(service=EdgeService(EdgeChromiumDriverManager().install()))

        driver.get('https://cht.konnect.csttestserver.com/')
        time.sleep(3)
        driver.close()
        print('CHT opened and closed successfully')

test_obj = Chrome_WDM_Config()
test_obj.chrome_wdm_test()